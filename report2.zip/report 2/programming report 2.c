//
//  programming report 2.c
//  programming report 2
//
//  Created by 김애리 on 2020/07/04.
//

#include "programming report 2.h"
#include <stdio.h>


void server();


char file_name[50];
int num;
FILE* report2;

int main(){
    
    printf("나누고 싶은 파일 이름을 입력하세요.\n");
    scanf("%[^\n]s", file_name);
    
    printf("몇 개로 나누고 싶나요?\n");
    scanf("%d", num);
    
    printf("해당 요청을 server에게 전달하겠습니다.\n");
    
    server();
    
    return 0;
}


void server(){
    
    printf("store %s divided_%s_[i] -%d\n", file_name, file_name, num);
    
    for(int i=0; i<num; i++)
        printf("divided_%s_[%d] is stored\n", file_name, i);
  
    report2 = fopen("report2.txt", "w");
    fprintf(report2, "divided_%s    %d  \n", file_name, num);
    fclose(report2);

}
