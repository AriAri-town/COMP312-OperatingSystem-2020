#include <stdio.h>
#include <pthread.h>
#include <time.h>
#include <stdlib.h>

int number[100];
int lock;
int count[10][100]; // 각 스레드별로 카운팅 
int sum[10];	// 각 스레드에서 발생한 난수 빈도 합 

void *t_function(void *data){
	
	int thread_number = *(int*)data;
	int i=0;
	int x, y;
	lock = 0;

	// 난수 생성 
	srand((unsigned int) time (NULL));

	while (i<100000)		
	{
		x = rand()%100;
		number[x]++;
		count[thread_number][x]++;
		i++;
	}

	for(i=0; i<100; i++){
		y=count[thread_number][i];
		sum[thread_number] += y;
	}


}


int main(){

	pthread_t p_thread[10];
	FILE *result;
	int thr_id;
	int sum_all_thread=0;
	int sum_all=0;
	

	// 10 개의 스레드 생성
	for(int i=0; i<10; i++){
		thr_id = pthread_create(&p_thread[i], NULL, t_function, (void*)&i);

		if (thr_id<0){
			perror("thread create error: ");
			exit(0);
		}
		lock = 1;
		while(lock);	
	}

	// Thread 종료
	for(int i=0; i<10; i++)
		pthread_join(p_thread[i], NULL);


	// 결과를 파일에 출력
	result = fopen("result.dat", "w");
	
	// number[100] 출력
	for(int i=0; i<100; i++){
		fprintf(result, "%02d의 빈도 : %05d\n", i, number[i]);
		sum_all += number[i];
	}
	fprintf(result, "총 난수 발생 빈도 : %07d\n\n\n", sum_all);

	// 스레드별 빈도 출력
	for(int i=0; i<10; i++){
		for(int j=0; j<100; j++)
			fprintf(result, "스레드 %d에서 %02d의 빈도 : %04d\n", i, j, count[i][j]);
		fprintf(result, "스레드 %d의 총 난수 발생 빈도 : %05d\n\n", i, sum[i]);
		sum_all_thread += sum[i];
	}

	fprintf(result, "모든 스레드에서 발생한 총 난수 빈도 : %07d\n\n\n", sum_all_thread);

	fclose(result);


	return 0;
}


